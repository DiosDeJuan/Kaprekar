
package com.mycompany.kaprekar;

import java.util.Scanner;

/**
 *
 * Isaac Juan De Dios Victoria Mercado
 * 
 */

public class Main {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese un número de cuatro dígitos: ");
            int number = scanner.nextInt();
            
            // Asegurarse de que el número tenga al menos dos dígitos distintos
            while (!hasAtLeastTwoDistinctDigits(number)) {
                System.out.print("El número debe tener al menos dos dígitos distintos. Inténtalo de nuevo: ");
                number = scanner.nextInt();
            }
            
            // Asegurarse de que el número tenga 4 dígitos
            while (String.valueOf(number).length() != 4 || !hasAtLeastTwoDistinctDigits(number)) {
            System.out.print("El número debe tener exactamente 4 dígitos y al menos dos dígitos distintos. Inténtalo de nuevo: ");
            number = scanner.nextInt();
            }
            
            Kaprekar kaprekar = new Kaprekar(number);
            kaprekar.findKaprekarConstant();
        }
    }

    // Método auxiliar para verificar si el número tiene al menos dos dígitos distintos
    private static boolean hasAtLeastTwoDistinctDigits(int num) {
        String numStr = String.valueOf(num);
        return numStr.chars().distinct().count() > 1;
    }
}