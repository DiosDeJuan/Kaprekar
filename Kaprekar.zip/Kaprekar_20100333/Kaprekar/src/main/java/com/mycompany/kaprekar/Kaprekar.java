
package com.mycompany.kaprekar;

import java.util.Arrays;

/**
 *
 * Isaac Juan De Dios Victoria Mercado
 * 
 */

public class Kaprekar {

    private int number;
    private int iterations;

    public Kaprekar(int number) {
        this.number = number;
        this.iterations = 0;
    }

    // Método para ordenar los dígitos en orden ascendente
    private int sortAsc(int num) {
        char[] digits = String.valueOf(num).toCharArray();
        Arrays.sort(digits);
        return Integer.parseInt(new String(digits));
    }

    // Método para ordenar los dígitos en orden descendente
    private int sortDesc(int num) {
        char[] digits = String.valueOf(num).toCharArray();
        Arrays.sort(digits);
        StringBuilder sortedDesc = new StringBuilder(new String(digits)).reverse();
        return Integer.parseInt(sortedDesc.toString());
    }

    // Método principal para encontrar la constante de Kaprekar
    public void findKaprekarConstant() {
        int currentNumber = this.number;

        while (currentNumber != 6174) {
            // Asegurarse de que el número tenga 4 dígitos (rellenar con ceros si es necesario)
            currentNumber = padWithZeros(currentNumber);

            int asc = sortAsc(currentNumber);
            int desc = sortDesc(currentNumber);

            int result = desc - asc;
            iterations++;

            System.out.println(desc + " - " + asc + " = " + result);

            currentNumber = result;
        }

        System.out.println("Se llegó a la constante de Kaprekar 6174 en " + iterations + " iteraciones.");
    }

    // Método auxiliar para asegurarse de que el número tenga 4 dígitos (rellenar con ceros si es necesario)
    private int padWithZeros(int num) {
        String numStr = String.valueOf(num);
        while (numStr.length() < 4) {
            numStr = "0" + numStr;
        }
        return Integer.parseInt(numStr);
    }
}
